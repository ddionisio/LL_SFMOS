﻿
public enum UpgradeType {
    None = -1,

    Time,
    Mucus,
    Neutrophil //summon
}
