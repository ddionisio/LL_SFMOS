﻿
public struct Tags {
    public static string mucus = "Mucus";
    public static string cell = "Cell";
    public static string pathogen = "Pathogen";
}
