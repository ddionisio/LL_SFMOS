﻿using UnityEngine;

namespace M8 {
    public class LocalizeAttribute : PropertyAttribute {

    }
}
