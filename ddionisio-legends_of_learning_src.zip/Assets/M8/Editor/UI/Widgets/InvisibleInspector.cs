﻿using UnityEditor;

namespace M8.UI.Widgets {
    [CustomEditor(typeof(Invisible))]
    public class InvisibleInspector : Editor {
        public override void OnInspectorGUI() {
        }
    }
}