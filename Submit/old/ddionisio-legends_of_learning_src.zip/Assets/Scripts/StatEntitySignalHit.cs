﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct StatEntitySignalHit {
    public Vector2 point;
    public Vector2 dir; //the hitter's direction of movement during impact
}
